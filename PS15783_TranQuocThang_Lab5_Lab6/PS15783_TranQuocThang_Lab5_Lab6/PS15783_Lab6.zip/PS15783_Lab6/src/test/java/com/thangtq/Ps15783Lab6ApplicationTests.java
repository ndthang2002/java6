package com.thangtq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ps15783Lab6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
