package com.thangtq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ps15783Lab5Application {

	public static void main(String[] args) {
		SpringApplication.run(Ps15783Lab5Application.class, args);
	}

}
